import { Banner } from "./components/Banner/Banner";
import Navbar from "./components/Home/Navbar";
import React from "react";
import Marqueeslider from "./components/Marquee/Marquee";
import TopSelling from "./components/Topsellingproduct/TopSelling";
import Superfood from "./components/Superfood/Superfood";
import Ads from "./components/Ads/Ads";
import Testimonial from "./components/Testimonial/Testimonial";
import Safe_Payment from "./components/Safe_Payment/Safe_Payment";
import Footer from "./components/Footer/Footer";
import SellingProduct from "./components/SellingProduct/SellingProduct";

function App() {
  return (
    <>
      <Navbar />
      <Banner />
      {/* <Marqueeslider />
      <TopSelling slidesToShow={6} />
      <Superfood />
   
      <Ads />
      <Testimonial />
      <Safe_Payment /> */}
      
      <SellingProduct />
         <TopSelling slidesToShow={4} />
      <Footer />
    </>
  );
}

export default App;
