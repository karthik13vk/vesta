import React from "react";

const Marquee = () => {
  return (
    <div className="marquee-section py-2 bg-bg_5">
      <div className="container mx-auto flex flex-row items-center">
        <ul className="">
          <li className="flex gap-1.5 text-white text-lg">
            <span className="font-bold">25k+</span> Customers Satisfied
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Marquee;
