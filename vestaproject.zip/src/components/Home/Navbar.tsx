import React from "react";
import logo from "./../../assets/images/logo.png";
import { Layout, Menu } from "antd";
import { UserOutlined, SearchOutlined } from "@ant-design/icons";

const { Header, Content } = Layout;
const Navbar = () => {
  return (
    <div>
      <div className="bg-bg_4 py-2 flex justify-center align-middle text-1xl text-text_1 font-bold">
        Free Delivery Across India
      </div>
      <Layout>
        <div className="bg-bg_2 text-5xl text-text_3 py-3 font-primary">
          <div className="container mx-auto flex flex-row items-center">
            <div className="basis-5/12">
              <div className="header-main">
                <div className="header-left">
                  <ul className="flex align-middle justify-between gap-4">
                    <li className="flex items-center">
                      <a href="" className="text-text_1 text-lg  ">
                        Home
                      </a>
                    </li>
                    <li className="flex items-center">
                      <a href="" className="text-text_1 text-lg ">
                        All Products
                      </a>
                    </li>
                    <li className="flex items-center">
                      <a href="" className="text-text_1 text-lg ">
                        Kitchen Essential
                      </a>
                    </li>
                    <li className="flex items-center">
                      <a href="" className="text-text_1 text-lg ">
                        Nutrition Essential
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="basis-2/12">
              <div className="main-logo flex items-center justify-center">
                <img src={logo} alt="logo" />
              </div>
            </div>
            <div className="basis-5/12">
              <div className="header-right flex items-center justify-between">
                <div className="flex gap-3 text-text_1 ">
                  <a href="javascript:void(0)" className="text-text_1 text-lg font-primary">
                    Personal Care
                  </a>
                  <a href="javascript:void(0)" className="text-text_1 text-lg font-primary">
                    Blog
                  </a>
                </div>

                <div className="relative h-[40px] flex items-center">
                  <input
                    type="text"
                    className="py-1 px-3 text-lg bg-inputcolor rounded-full w-[150px]  focus:outline-text_2  active:bg-text_2 "
                  />
                  <SearchOutlined className="absolute top-3 right-2 text-lg text-text_1 " />
                </div>
                <div>
                  <a href="javascript:void(0)" className="text-lg flex items-center justify-center text-text_1 ">
                    <UserOutlined />
                  </a>
                </div>
                <div>
                  <a href="javascript:void(0)" className=" transition-all duration-300  bg-text_2 text-white rounded-md p-2 border border-text_2 flex items-center justify-center gap-1.5 text-lg        hover:text-text_1 hover:bg-white hover:border hover:border-text_2">
                    <UserOutlined /> Cart (1)
                  </a>
                </div>
              </div>
              <div></div>
            </div>
          </div>
        </div>
      </Layout>
    </div>
  );
};

export default Navbar;
