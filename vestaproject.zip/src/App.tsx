import { Banner } from "./components/Banner/Banner";
import Navbar  from "./components/Home/Navbar";
import React from "react";
import Marquee from "./components/Marquee/Marquee";


function App() {
  return (
    <>
      <Navbar/>
      <Banner/>
      <Marquee/>
    </>
  );
}

export default App;
