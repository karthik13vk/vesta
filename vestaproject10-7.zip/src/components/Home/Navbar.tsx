import React, { useState } from 'react';
import logo from "./../../assets/images/logo.png";
import products from "./../../assets/images/products/product-img.png";
import { BsCart4 } from "react-icons/bs";
import { CgMenuRight } from "react-icons/cg";
import { Layout, Menu } from "antd";
import { UserOutlined, SearchOutlined } from "@ant-design/icons";
import "./Navbar.scss"
import { Button, ConfigProvider, Drawer, Space } from 'antd';
import { createStyles, useTheme } from 'antd-style';
import type { DrawerClassNames, DrawerStyles } from 'antd/es/drawer/DrawerPanel';

const { Header, Content } = Layout;

// ✅ Define styles using `createStyles`
const useStyle = createStyles(({ token }) => ({
  'my-drawer-body': {
    background: token.blue1,
  },
  'my-drawer-mask': {
    boxShadow: 'inset 0 0 15px #fff',
  },
  'my-drawer-header': {
    background: token.green1,
  },
  'my-drawer-footer': {
    color: token.colorPrimary,
  },
  'my-drawer-content': {
    borderLeft: '2px dotted #333',
  },
}));
const Navbar = () => {
    const [open, setOpen] = useState([false, false]);

  const { styles } = useStyle();
  const token = useTheme();

  // ✅ Drawer toggle function
  const toggleDrawer = (index: number, status: boolean) => {
    const updated = [...open];
    updated[index] = status;
    setOpen(updated);
  };

  // ✅ Custom classNames for Drawer
  const classNames: DrawerClassNames = {
    body: styles['my-drawer-body'],
    mask: styles['my-drawer-mask'],
    header: styles['my-drawer-header'],
    footer: styles['my-drawer-footer'],
    content: styles['my-drawer-content'],
  };
    const drawerStyles: DrawerStyles = {
    mask: {
      backdropFilter: 'blur(10px)',
    },
    content: {
      boxShadow: '-10px 0 10px #666',
    },
    header: {
      borderBottom: `1px solid ${token.colorPrimary}`,
    },
    body: {
      fontSize: token.fontSizeLG,
    },
    footer: {
      borderTop: `1px solid ${token.colorBorder}`,
    },
  };

  return (
    <div className='nav-section'>
      <div className="flex justify-center py-2 font-bold align-middle bg-bg_4 text-1xl text-text_1">
        Free Delivery Across India
      </div>
      <Layout>
        <div className="py-3 text-5xl bg-bg_2 text-text_3 font-primary">
          <div className="container flex flex-row items-center justify-between px-4 mx-auto lg:px-6 ">
            <div className="hidden basis-5/12 lg:block">
              <div className="header-main">
                <div className="header-left">
                  <ul className="flex justify-between gap-4 align-middle">
                    <li className="flex items-center">
                      <a href="" className="text-lg text-text_1 ">
                        Home
                      </a>
                    </li>
                    <li className="flex items-center">
                      <a href="" className="text-lg text-text_1 ">
                        All Products
                      </a>
                    </li>
                    <li className="flex items-center">
                      <a href="" className="text-lg text-text_1 ">
                        Kitchen Essential
                      </a>
                    </li>
                    <li className="flex items-center">
                      <a href="" className="text-lg text-text_1 ">
                        Nutrition Essential
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="basis-2/12">
              <div className="flex items-center justify-center main-logo">
                <img src={logo} alt="logo" />
              </div>
            </div>
            <div className="basis-5/12">
              <div className="flex items-center justify-between header-right">
                <div className="hidden gap-3 text-text_1 lg:flex">
                  <a
                    href="javascript:void(0)"
                    className="text-lg text-text_1 font-primary"
                  >
                    Personal Care
                  </a>
                  <a
                    href="javascript:void(0)"
                    className="text-lg text-text_1 font-primary"
                  >
                    Blog
                  </a>
                </div>

                <div className="relative h-[40px]  items-center flex ">
                  <input
                    type="text"
                    className="py-1 px-3 text-lg bg-inputcolor rounded-full w-[150px]  focus:outline-text_2 hidden lg:flex active:bg-text_2 "
                  />
                  <SearchOutlined className="text-lg lg:absolute top-3 right-2 text-text_1 " />
                </div>
                <div className="flex gap-2">
                  <a
                    href="javascript:void(0)"
                    className="flex items-center justify-center text-lg text-text_1 "
                  >
                    <UserOutlined />
                  </a>
              
                </div>
                <div className="flex gap-2">
                
                  <a
                    href="javascript:void(0)"
                    className="flex items-center justify-center text-lg text-text_1 lg:hidden"
                  >
                    <BsCart4 />
                  </a>
                </div>
                <div>
                 
                   <a
                  onClick={() => toggleDrawer(0, true)}
                  className="tetransition-all duration-300  bg-text_2 text-white rounded-md p-2 border border-text_2 flex items-center justify-center gap-1.5 text-lg        hover:text-text_1 hover:bg-white hover:border hover:border-text_2 hidden lg:flex cursor-pointer"
                >
                   <BsCart4 />
                    Cart (1)
                </a>
                  <a
                    href="javascript:void(0)"
                    className="  text-text_2 rounded-md p-2 flex items-center justify-center gap-1.5  text-4xl      flex lg:hidden"
                  >
                    <CgMenuRight />
                  </a>
              
        
                </div>
              </div>
              <div></div>
            </div>
          </div>
        </div>
         <Drawer
          title="Free Delivery On All Orders"
          placement="right"
          footer="Footer"
          onClose={() => toggleDrawer(0, false)}
          open={open[0]}
          classNames={classNames}
          styles={drawerStyles}
        >
         <div className='flex'>
          <div className="w-[20%]">
            <img src={products} alt="img" className=""/>
          </div>
          <div  className='flex'>
            <div>1</div>
            <div>1</div>
          </div>
         </div>
          <p>Some contents...</p>
          <p>Some contents...</p>
        </Drawer>
      </Layout>
    </div>
  );
};

export default Navbar;
