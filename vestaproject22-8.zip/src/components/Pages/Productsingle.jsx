import React from 'react'
import Product_Details from "./../Product_details/Product_Details";

import Benefit from "./../Benefit/Benefit";
import Testimonial from '../Testimonial/Testimonial';
import Superfood from '../Superfood/Superfood';
const Productsingle = () => {
    return (
        <>
            <Product_Details />
            <Benefit />
             <Superfood />
            <Testimonial />
        </>
    )
}

export default Productsingle